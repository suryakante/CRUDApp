var mongoose = require('mongoose');

 var crud ={
     title: "crudapp",
     statusCode: 200
 };

 //Connect to DB
 mongoose.Promise = global.Promise;
 mongoose.connect('mongodb://surya:surya888@ds331135.mlab.com:31135/crudappdb',{useNewUrlParser: true});

 //Build a Schema
 var myData = mongoose.Schema({
     name: {
         type: String,
         required: true
     },
     email:{
         type: String,
         required: true
     }
 },{collection: 'crudData'});

 //Create a Model
 var model = mongoose.model('crudData', myData);

 //Perform CRUD operations

 //Create/Insert Operation
 crud.insertData = function(req, res){

    var reqBody = req.body;

    var reqData = {
        name : reqBody.name,
        email : reqBody.email
    };

    var saveData = new model(reqData);

    saveData.save(function(err, successData){
        if(err){
            res.send({
                statusCode: 500,
                message: 'Failed to save the data'
            });
        }else{
            res.send({
                statusCode: 200,
                message: 'Data saved Successfully',
                data: successData
            });
        }
    });
 };

 // Read/Get Operation

 crud.getData = function(req,res){
    model.find({}, function(err, successData){
        if(err){
            res.send({
                statusCode: 500,
                message: 'Failed to fetch data fron Database'
            });
        }else{
            res.send({
                statusCode: 200,
                message: 'Data fetched Successfully',
                data: successData
            });
        }
    });
 };

 //Delete Operation

 crud.deleteData = function(req, res){
    var reqBody = req.params.name;

    model.findOneAndRemove(reqBody, function(err, successData){
        if(err){
            res.send({
                statusCode: 500,
                message: 'Failed to delete the data'
            });
        }else{
            res.send({
                statusCode: 200,
                message: 'Data deleted Successfully',
                data: successData
            });
        }
    });
 };

 // Update Operation
 crud.updateData = function(req, res){

    var reqBody = req.body;

    var reqData = {
        name : reqBody.name,
        email : reqBody.email
    };

    var id = req.params.id;

    model.findOneAndUpdate(id,reqData,function(err, successData){
        if(err){
            res.send({
                statusCode: 500,
                message: 'Failed to update the data'
            });
        }else{
            res.send({
                statusCode: 200,
                message: 'Data updated Successfully',
                data: successData
            });
        }
    });
 };

 module.exports = crud; 