var express = require('express');
var router = express.Router();
var crud = require('./api/crudapp/crud');

router.post('/insert',crud.insertData);
router.get('/get', crud.getData);
router.delete('/delete/:name', crud.deleteData);
router.put('/update/:id', crud.updateData);


module.exports = router;